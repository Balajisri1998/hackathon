<?php 
require_once("config.php");


 		  $_SuserName = $_POST['username'];
		  $_Spassword = $_POST['password'];
		  


		if((isset($_SuserName) && $_SuserName !='') &&(isset($_Spassword)&&  $_Spassword !=''))
		{
		 
		 require_once("user_validation.php");

		}
		else
		{
		echo "Please fill LoginEmail and Password";
		}
?>