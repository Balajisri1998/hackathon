<?php
/*get the Flight Data in Post Method*/
$_Adata = json_decode($_POST["data"],1);
/*get the Employee Name */
$employeeName = $_POST['empName'];

/*$_Adata = '{
  "6E_2019-05-20": {
    "status_code": 0,
    "data": {
      "origin_airport_code": "MAA",
      "dest_airport_code": "CJB",
      "origin_airport_name": "Chennai",
      "dest_airport_name": "Coimbatore",
      "adult": "1",
      "child": 0,
      "infant": 0,
      "date_departure": "2019-05-20",
      "return_date_departure": "",
      "time_departure": "14:10",
      "time_arrival": "15:15",
      "return_time_departure": "",
      "return_time_arrival": "",
      "tax": 627,
      "base_fare": 1431,
      "discount": 0,
      "cancellation_fee": {
        "ADT": "3000"
      },
      "seats": 0,
      "trip_type": "O",
      "stops": 0,
      "currency_type": "INR",
      "return_stops": "",
      "via_flights": [
        {
          "origin_airport_code": "MAA",
          "dest_airport_code": "CJB",
          "origin_airport_name": "Chennai",
          "dest_airport_name": "Coimbatore",
          "origin_airport_details": {
            "airport_detail_id": "7277",
            "airport_name": "Chennai International Airport",
            "city_name": "Chennai",
            "airport_code": "MAA",
            "continent_code": "AS",
            "country_code": "IN",
            "coordinates": [
              "12.99000549",
              "80.16929626"
            ],
            "airport_type": "large_airport",
            "time_zone": "Asia/Kolkata",
            "offset": "+05:30",
            "status": "Y"
          },
          "dest_airport_details": {
            "airport_detail_id": "7268",
            "airport_name": "Coimbatore International Airport",
            "city_name": "Coimbatore",
            "airport_code": "CJB",
            "continent_code": "AS",
            "country_code": "IN",
            "coordinates": [
              "11.02999973",
              "77.04340363"
            ],
            "airport_type": "medium_airport",
            "time_zone": "Asia/Kolkata",
            "offset": "+05:30",
            "status": "Y"
          },
          "arrival_terminal": "",
          "departure_terminal": "",
          "time_departure": "14:10",
          "time_arrival": "15:15",
          "arrival_date": "2019-05-20",
          "departure_date": "2019-05-20",
          "meal_code": "",
          "cabin_class": "E",
          "faretypename": "Refundable",
          "faretype_code": "R",
          "trip_type": "O",
          "flight_number": 881,
          "airline_code": "6E",
          "airline_name": "Indigo Air",
          "travel_time": "1h 5m",
          "total_time": "1h 5m",
          "layover_time": "",
          "fare_basic_code": {
            "adult": "Q0IP",
            "child": "",
            "infant": ""
          },
          "baggage_allowance": {
            "HB": {
              "ADT": {
                "Weight": "10",
                "Unit": "kg"
              }
            },
            "CB": {
              "ADT": {
                "Weight": "15",
                "Unit": "kg"
              }
            }
          },
          "operating_airline_code": "",
          "operating_airline_name": "",
          "operating_flight_number": ""
        }
      ],
      "passenger_fare": [
        {
          "passenger_type": "ADT",
          "base_fare": 1431,
          "tax": 627,
          "old_base_fare": 0,
          "old_tax": 0,
          "discount": 0,
          "taxBreakUpDetails": [
            {
              "taxCode": "RCF",
              "taxAmount": 50,
              "taxDescription": "Other Tax"
            },
            {
              "taxCode": "YQ",
              "taxAmount": 200,
              "taxDescription": "Airline Fuel Charge"
            },
            {
              "taxCode": "TTF",
              "taxAmount": 57,
              "taxDescription": "Other Tax"
            },
            {
              "taxCode": "IN",
              "taxAmount": 153,
              "taxDescription": "User Development Fee"
            },
            {
              "taxCode": "UDF",
              "taxAmount": 81,
              "taxDescription": "User Development Fee"
            },
            {
              "taxCode": "GST",
              "taxAmount": 86,
              "taxDescription": "Government Service Tax"
            }
          ]
        }
      ]
    }
  },
  "SG_2019-05-20": {
    "status_code": 0,
    "data": {
      "origin_airport_code": "MAA",
      "dest_airport_code": "CJB",
      "origin_airport_name": "Chennai",
      "dest_airport_name": "Coimbatore",
      "adult": "1",
      "child": 0,
      "infant": 0,
      "date_departure": "2019-05-20",
      "return_date_departure": "",
      "time_departure": "09:10",
      "time_arrival": "10:10",
      "return_time_departure": "",
      "return_time_arrival": "",
      "tax": 581,
      "base_fare": 4800,
      "discount": 0,
      "cancellation_fee": {
        "ADT": "3000"
      },
      "seats": 0,
      "trip_type": "O",
      "stops": 0,
      "currency_type": "INR",
      "return_stops": "",
      "via_flights": [
        {
          "origin_airport_code": "MAA",
          "dest_airport_code": "CJB",
          "origin_airport_name": "Chennai",
          "dest_airport_name": "Coimbatore",
          "origin_airport_details": {
            "airport_detail_id": "7277",
            "airport_name": "Chennai International Airport",
            "city_name": "Chennai",
            "airport_code": "MAA",
            "continent_code": "AS",
            "country_code": "IN",
            "coordinates": [
              "12.99000549",
              "80.16929626"
            ],
            "airport_type": "large_airport",
            "time_zone": "Asia/Kolkata",
            "offset": "+05:30",
            "status": "Y"
          },
          "dest_airport_details": {
            "airport_detail_id": "7268",
            "airport_name": "Coimbatore International Airport",
            "city_name": "Coimbatore",
            "airport_code": "CJB",
            "continent_code": "AS",
            "country_code": "IN",
            "coordinates": [
              "11.02999973",
              "77.04340363"
            ],
            "airport_type": "medium_airport",
            "time_zone": "Asia/Kolkata",
            "offset": "+05:30",
            "status": "Y"
          },
          "arrival_terminal": "",
          "departure_terminal": "",
          "time_departure": "09:10",
          "time_arrival": "10:10",
          "arrival_date": "2019-05-20",
          "departure_date": "2019-05-20",
          "meal_code": "",
          "cabin_class": "E",
          "faretypename": "Refundable",
          "faretype_code": "R",
          "trip_type": "O",
          "flight_number": 501,
          "airline_code": "SG",
          "airline_name": "Spice Jet",
          "travel_time": "1h 0m",
          "total_time": "1h 0m",
          "layover_time": "",
          "fare_basic_code": {
            "adult": "LSAVER",
            "child": "",
            "infant": ""
          },
          "baggage_allowance": {
            "HB": {
              "ADT": {
                "Weight": "7",
                "Unit": "kg"
              }
            },
            "CB": {
              "ADT": {
                "Weight": "15",
                "Unit": "kg"
              }
            }
          },
          "operating_airline_code": "",
          "operating_airline_name": "",
          "operating_flight_number": ""
        }
      ],
      "passenger_fare": [
        {
          "passenger_type": "ADT",
          "base_fare": 4800,
          "tax": 581,
          "old_base_fare": 0,
          "old_tax": 0,
          "discount": 0,
          "taxBreakUpDetails": [
            {
              "taxCode": "RCS",
              "taxAmount": 100,
              "taxDescription": "Other Tax"
            },
            {
              "taxCode": "IN",
              "taxAmount": 153,
              "taxDescription": "User Development Fee"
            },
            {
              "taxCode": "UDF",
              "taxAmount": 82,
              "taxDescription": "User Development Fee"
            },
            {
              "taxCode": "GST",
              "taxAmount": 246,
              "taxDescription": "Government Service Tax"
            }
          ]
        }
      ]
    }
  },
  "G8_2019-05-20": {
    "status_code": 1,
    "data": "No availability"
  },
  "SB_2019-05-20": {
    "status_code": 0,
    "data": {
      "origin_airport_code": "MAA",
      "dest_airport_code": "CJB",
      "origin_airport_name": "Chennai",
      "dest_airport_name": "Coimbatore",
      "adult": "1",
      "child": 0,
      "infant": 0,
      "date_departure": "2019-05-20",
      "return_date_departure": "",
      "time_departure": "13:20",
      "time_arrival": "14:30",
      "return_time_departure": "",
      "return_time_arrival": "",
      "tax": 482,
      "base_fare": 1350,
      "discount": 0,
      "cancellation_fee": {
        "ADT": 2500
      },
      "seats": 9,
      "trip_type": "O",
      "stops": 0,
      "currency_type": "INR",
      "return_stops": 0,
      "via_flights": [
        {
          "origin_airport_code": "MAA",
          "dest_airport_code": "CJB",
          "origin_airport_name": "Chennai",
          "dest_airport_name": "Coimbatore",
          "origin_airport_details": {
            "airport_detail_id": "7277",
            "airport_name": "Chennai International Airport",
            "city_name": "Chennai",
            "airport_code": "MAA",
            "continent_code": "AS",
            "country_code": "IN",
            "coordinates": [
              "12.99000549",
              "80.16929626"
            ],
            "airport_type": "large_airport",
            "time_zone": "Asia/Kolkata",
            "offset": "+05:30",
            "status": "Y"
          },
          "dest_airport_details": {
            "airport_detail_id": "7268",
            "airport_name": "Coimbatore International Airport",
            "city_name": "Coimbatore",
            "airport_code": "CJB",
            "continent_code": "AS",
            "country_code": "IN",
            "coordinates": [
              "11.02999973",
              "77.04340363"
            ],
            "airport_type": "medium_airport",
            "time_zone": "Asia/Kolkata",
            "offset": "+05:30",
            "status": "Y"
          },
          "arrival_terminal": "",
          "departure_terminal": "1",
          "time_departure": "13:20",
          "time_arrival": "14:30",
          "arrival_date": "2019-05-20",
          "departure_date": "2019-05-20",
          "meal_code": "S",
          "cabin_class": "E",
          "faretypename": "Refundable",
          "faretype_code": "R",
          "trip_type": "O",
          "flight_number": 429,
          "airline_code": "AI",
          "airline_name": "Air India",
          "travel_time": "1h 10m",
          "total_time": "1h 10m",
          "layover_time": "",
          "fare_basic_code": {
            "adult": "SAP8",
            "child": "",
            "infant": ""
          },
          "baggage_allowance": {
            "CB": {
              "ADT": {
                "Weight": 25,
                "Unit": "kg"
              }
            }
          },
          "operating_airline_code": "AI",
          "operating_airline_name": "Air India",
          "operating_flight_number": 429,
          "mealAvailable": "YES"
        }
      ],
      "passenger_fare": [
        {
          "passenger_type": "ADT",
          "base_fare": 1350,
          "tax": 482,
          "old_base_fare": 0,
          "old_tax": 0,
          "discount": 0,
          "taxBreakUpDetails": [
            {
              "taxCode": "YR",
              "taxAmount": 170,
              "taxDescription": "Service Charge"
            },
            {
              "taxCode": "IN",
              "taxAmount": 82,
              "taxDescription": "User Development Fee"
            },
            {
              "taxCode": "GST",
              "taxAmount": 76,
              "taxDescription": "Government Service Tax"
            },
            {
              "taxCode": "WO",
              "taxAmount": 154,
              "taxDescription": "Passenger Service Fee"
            }
          ]
        }
      ]
    }
  },
  "6E_2019-05-21": {
    "status_code": 0,
    "data": {
      "origin_airport_code": "MAA",
      "dest_airport_code": "CJB",
      "origin_airport_name": "Chennai",
      "dest_airport_name": "Coimbatore",
      "adult": "1",
      "child": 0,
      "infant": 0,
      "date_departure": "2019-05-21",
      "return_date_departure": "",
      "time_departure": "12:55",
      "time_arrival": "14:00",
      "return_time_departure": "",
      "return_time_arrival": "",
      "tax": 627,
      "base_fare": 1431,
      "discount": 0,
      "cancellation_fee": {
        "ADT": "3000"
      },
      "seats": 0,
      "trip_type": "O",
      "stops": 0,
      "currency_type": "INR",
      "return_stops": "",
      "via_flights": [
        {
          "origin_airport_code": "MAA",
          "dest_airport_code": "CJB",
          "origin_airport_name": "Chennai",
          "dest_airport_name": "Coimbatore",
          "origin_airport_details": {
            "airport_detail_id": "7277",
            "airport_name": "Chennai International Airport",
            "city_name": "Chennai",
            "airport_code": "MAA",
            "continent_code": "AS",
            "country_code": "IN",
            "coordinates": [
              "12.99000549",
              "80.16929626"
            ],
            "airport_type": "large_airport",
            "time_zone": "Asia/Kolkata",
            "offset": "+05:30",
            "status": "Y"
          },
          "dest_airport_details": {
            "airport_detail_id": "7268",
            "airport_name": "Coimbatore International Airport",
            "city_name": "Coimbatore",
            "airport_code": "CJB",
            "continent_code": "AS",
            "country_code": "IN",
            "coordinates": [
              "11.02999973",
              "77.04340363"
            ],
            "airport_type": "medium_airport",
            "time_zone": "Asia/Kolkata",
            "offset": "+05:30",
            "status": "Y"
          },
          "arrival_terminal": "",
          "departure_terminal": "",
          "time_departure": "12:55",
          "time_arrival": "14:00",
          "arrival_date": "2019-05-21",
          "departure_date": "2019-05-21",
          "meal_code": "",
          "cabin_class": "E",
          "faretypename": "Refundable",
          "faretype_code": "R",
          "trip_type": "O",
          "flight_number": 238,
          "airline_code": "6E",
          "airline_name": "Indigo Air",
          "travel_time": "1h 5m",
          "total_time": "1h 5m",
          "layover_time": "",
          "fare_basic_code": {
            "adult": "Q0IP",
            "child": "",
            "infant": ""
          },
          "baggage_allowance": {
            "HB": {
              "ADT": {
                "Weight": "10",
                "Unit": "kg"
              }
            },
            "CB": {
              "ADT": {
                "Weight": "15",
                "Unit": "kg"
              }
            }
          },
          "operating_airline_code": "",
          "operating_airline_name": "",
          "operating_flight_number": ""
        }
      ],
      "passenger_fare": [
        {
          "passenger_type": "ADT",
          "base_fare": 1431,
          "tax": 627,
          "old_base_fare": 0,
          "old_tax": 0,
          "discount": 0,
          "taxBreakUpDetails": [
            {
              "taxCode": "RCF",
              "taxAmount": 50,
              "taxDescription": "Other Tax"
            },
            {
              "taxCode": "YQ",
              "taxAmount": 200,
              "taxDescription": "Airline Fuel Charge"
            },
            {
              "taxCode": "TTF",
              "taxAmount": 57,
              "taxDescription": "Other Tax"
            },
            {
              "taxCode": "IN",
              "taxAmount": 153,
              "taxDescription": "User Development Fee"
            },
            {
              "taxCode": "UDF",
              "taxAmount": 81,
              "taxDescription": "User Development Fee"
            },
            {
              "taxCode": "GST",
              "taxAmount": 86,
              "taxDescription": "Government Service Tax"
            }
          ]
        }
      ]
    }
  },
  "SG_2019-05-21": {
    "status_code": 0,
    "data": {
      "origin_airport_code": "MAA",
      "dest_airport_code": "CJB",
      "origin_airport_name": "Chennai",
      "dest_airport_name": "Coimbatore",
      "adult": "1",
      "child": 0,
      "infant": 0,
      "date_departure": "2019-05-21",
      "return_date_departure": "",
      "time_departure": "09:10",
      "time_arrival": "10:10",
      "return_time_departure": "",
      "return_time_arrival": "",
      "tax": 581,
      "base_fare": 4800,
      "discount": 0,
      "cancellation_fee": {
        "ADT": "3000"
      },
      "seats": 0,
      "trip_type": "O",
      "stops": 0,
      "currency_type": "INR",
      "return_stops": "",
      "via_flights": [
        {
          "origin_airport_code": "MAA",
          "dest_airport_code": "CJB",
          "origin_airport_name": "Chennai",
          "dest_airport_name": "Coimbatore",
          "origin_airport_details": {
            "airport_detail_id": "7277",
            "airport_name": "Chennai International Airport",
            "city_name": "Chennai",
            "airport_code": "MAA",
            "continent_code": "AS",
            "country_code": "IN",
            "coordinates": [
              "12.99000549",
              "80.16929626"
            ],
            "airport_type": "large_airport",
            "time_zone": "Asia/Kolkata",
            "offset": "+05:30",
            "status": "Y"
          },
          "dest_airport_details": {
            "airport_detail_id": "7268",
            "airport_name": "Coimbatore International Airport",
            "city_name": "Coimbatore",
            "airport_code": "CJB",
            "continent_code": "AS",
            "country_code": "IN",
            "coordinates": [
              "11.02999973",
              "77.04340363"
            ],
            "airport_type": "medium_airport",
            "time_zone": "Asia/Kolkata",
            "offset": "+05:30",
            "status": "Y"
          },
          "arrival_terminal": "",
          "departure_terminal": "",
          "time_departure": "09:10",
          "time_arrival": "10:10",
          "arrival_date": "2019-05-21",
          "departure_date": "2019-05-21",
          "meal_code": "",
          "cabin_class": "E",
          "faretypename": "Refundable",
          "faretype_code": "R",
          "trip_type": "O",
          "flight_number": 501,
          "airline_code": "SG",
          "airline_name": "Spice Jet",
          "travel_time": "1h 0m",
          "total_time": "1h 0m",
          "layover_time": "",
          "fare_basic_code": {
            "adult": "LSAVER",
            "child": "",
            "infant": ""
          },
          "baggage_allowance": {
            "HB": {
              "ADT": {
                "Weight": "7",
                "Unit": "kg"
              }
            },
            "CB": {
              "ADT": {
                "Weight": "15",
                "Unit": "kg"
              }
            }
          },
          "operating_airline_code": "",
          "operating_airline_name": "",
          "operating_flight_number": ""
        }
      ],
      "passenger_fare": [
        {
          "passenger_type": "ADT",
          "base_fare": 4800,
          "tax": 581,
          "old_base_fare": 0,
          "old_tax": 0,
          "discount": 0,
          "taxBreakUpDetails": [
            {
              "taxCode": "RCS",
              "taxAmount": 100,
              "taxDescription": "Other Tax"
            },
            {
              "taxCode": "IN",
              "taxAmount": 153,
              "taxDescription": "User Development Fee"
            },
            {
              "taxCode": "UDF",
              "taxAmount": 82,
              "taxDescription": "User Development Fee"
            },
            {
              "taxCode": "GST",
              "taxAmount": 246,
              "taxDescription": "Government Service Tax"
            }
          ]
        }
      ]
    }
  },
  "G8_2019-05-21": {
    "status_code": 1,
    "data": "No availability"
  },
  "SB_2019-05-21": {
    "status_code": 0,
    "data": [
      "EMPTY"
    ]
  },
  "6E_2019-05-22": {
    "status_code": 0,
    "data": {
      "origin_airport_code": "MAA",
      "dest_airport_code": "CJB",
      "origin_airport_name": "Chennai",
      "dest_airport_name": "Coimbatore",
      "adult": "1",
      "child": 0,
      "infant": 0,
      "date_departure": "2019-05-22",
      "return_date_departure": "",
      "time_departure": "14:10",
      "time_arrival": "15:15",
      "return_time_departure": "",
      "return_time_arrival": "",
      "tax": 627,
      "base_fare": 1431,
      "discount": 0,
      "cancellation_fee": {
        "ADT": "3000"
      },
      "seats": 0,
      "trip_type": "O",
      "stops": 0,
      "currency_type": "INR",
      "return_stops": "",
      "via_flights": [
        {
          "origin_airport_code": "MAA",
          "dest_airport_code": "CJB",
          "origin_airport_name": "Chennai",
          "dest_airport_name": "Coimbatore",
          "origin_airport_details": {
            "airport_detail_id": "7277",
            "airport_name": "Chennai International Airport",
            "city_name": "Chennai",
            "airport_code": "MAA",
            "continent_code": "AS",
            "country_code": "IN",
            "coordinates": [
              "12.99000549",
              "80.16929626"
            ],
            "airport_type": "large_airport",
            "time_zone": "Asia/Kolkata",
            "offset": "+05:30",
            "status": "Y"
          },
          "dest_airport_details": {
            "airport_detail_id": "7268",
            "airport_name": "Coimbatore International Airport",
            "city_name": "Coimbatore",
            "airport_code": "CJB",
            "continent_code": "AS",
            "country_code": "IN",
            "coordinates": [
              "11.02999973",
              "77.04340363"
            ],
            "airport_type": "medium_airport",
            "time_zone": "Asia/Kolkata",
            "offset": "+05:30",
            "status": "Y"
          },
          "arrival_terminal": "",
          "departure_terminal": "",
          "time_departure": "14:10",
          "time_arrival": "15:15",
          "arrival_date": "2019-05-22",
          "departure_date": "2019-05-22",
          "meal_code": "",
          "cabin_class": "E",
          "faretypename": "Refundable",
          "faretype_code": "R",
          "trip_type": "O",
          "flight_number": 881,
          "airline_code": "6E",
          "airline_name": "Indigo Air",
          "travel_time": "1h 5m",
          "total_time": "1h 5m",
          "layover_time": "",
          "fare_basic_code": {
            "adult": "Q0IP",
            "child": "",
            "infant": ""
          },
          "baggage_allowance": {
            "HB": {
              "ADT": {
                "Weight": "10",
                "Unit": "kg"
              }
            },
            "CB": {
              "ADT": {
                "Weight": "15",
                "Unit": "kg"
              }
            }
          },
          "operating_airline_code": "",
          "operating_airline_name": "",
          "operating_flight_number": ""
        }
      ],
      "passenger_fare": [
        {
          "passenger_type": "ADT",
          "base_fare": 1431,
          "tax": 627,
          "old_base_fare": 0,
          "old_tax": 0,
          "discount": 0,
          "taxBreakUpDetails": [
            {
              "taxCode": "RCF",
              "taxAmount": 50,
              "taxDescription": "Other Tax"
            },
            {
              "taxCode": "YQ",
              "taxAmount": 200,
              "taxDescription": "Airline Fuel Charge"
            },
            {
              "taxCode": "TTF",
              "taxAmount": 57,
              "taxDescription": "Other Tax"
            },
            {
              "taxCode": "IN",
              "taxAmount": 153,
              "taxDescription": "User Development Fee"
            },
            {
              "taxCode": "UDF",
              "taxAmount": 81,
              "taxDescription": "User Development Fee"
            },
            {
              "taxCode": "GST",
              "taxAmount": 86,
              "taxDescription": "Government Service Tax"
            }
          ]
        }
      ]
    }
  },
  "SG_2019-05-22": {
    "status_code": 0,
    "data": {
      "origin_airport_code": "MAA",
      "dest_airport_code": "CJB",
      "origin_airport_name": "Chennai",
      "dest_airport_name": "Coimbatore",
      "adult": "1",
      "child": 0,
      "infant": 0,
      "date_departure": "2019-05-22",
      "return_date_departure": "",
      "time_departure": "09:10",
      "time_arrival": "10:10",
      "return_time_departure": "",
      "return_time_arrival": "",
      "tax": 581,
      "base_fare": 4800,
      "discount": 0,
      "cancellation_fee": {
        "ADT": "3000"
      },
      "seats": 0,
      "trip_type": "O",
      "stops": 0,
      "currency_type": "INR",
      "return_stops": "",
      "via_flights": [
        {
          "origin_airport_code": "MAA",
          "dest_airport_code": "CJB",
          "origin_airport_name": "Chennai",
          "dest_airport_name": "Coimbatore",
          "origin_airport_details": {
            "airport_detail_id": "7277",
            "airport_name": "Chennai International Airport",
            "city_name": "Chennai",
            "airport_code": "MAA",
            "continent_code": "AS",
            "country_code": "IN",
            "coordinates": [
              "12.99000549",
              "80.16929626"
            ],
            "airport_type": "large_airport",
            "time_zone": "Asia/Kolkata",
            "offset": "+05:30",
            "status": "Y"
          },
          "dest_airport_details": {
            "airport_detail_id": "7268",
            "airport_name": "Coimbatore International Airport",
            "city_name": "Coimbatore",
            "airport_code": "CJB",
            "continent_code": "AS",
            "country_code": "IN",
            "coordinates": [
              "11.02999973",
              "77.04340363"
            ],
            "airport_type": "medium_airport",
            "time_zone": "Asia/Kolkata",
            "offset": "+05:30",
            "status": "Y"
          },
          "arrival_terminal": "",
          "departure_terminal": "",
          "time_departure": "09:10",
          "time_arrival": "10:10",
          "arrival_date": "2019-05-22",
          "departure_date": "2019-05-22",
          "meal_code": "",
          "cabin_class": "E",
          "faretypename": "Refundable",
          "faretype_code": "R",
          "trip_type": "O",
          "flight_number": 501,
          "airline_code": "SG",
          "airline_name": "Spice Jet",
          "travel_time": "1h 0m",
          "total_time": "1h 0m",
          "layover_time": "",
          "fare_basic_code": {
            "adult": "LSAVER",
            "child": "",
            "infant": ""
          },
          "baggage_allowance": {
            "HB": {
              "ADT": {
                "Weight": "7",
                "Unit": "kg"
              }
            },
            "CB": {
              "ADT": {
                "Weight": "15",
                "Unit": "kg"
              }
            }
          },
          "operating_airline_code": "",
          "operating_airline_name": "",
          "operating_flight_number": ""
        }
      ],
      "passenger_fare": [
        {
          "passenger_type": "ADT",
          "base_fare": 4800,
          "tax": 581,
          "old_base_fare": 0,
          "old_tax": 0,
          "discount": 0,
          "taxBreakUpDetails": [
            {
              "taxCode": "RCS",
              "taxAmount": 100,
              "taxDescription": "Other Tax"
            },
            {
              "taxCode": "IN",
              "taxAmount": 153,
              "taxDescription": "User Development Fee"
            },
            {
              "taxCode": "UDF",
              "taxAmount": 82,
              "taxDescription": "User Development Fee"
            },
            {
              "taxCode": "GST",
              "taxAmount": 246,
              "taxDescription": "Government Service Tax"
            }
          ]
        }
      ]
    }
  },
  "G8_2019-05-22": {
    "status_code": 1,
    "data": "No availability"
  },
  "SB_2019-05-22": {
    "status_code": 0,
    "data": {
      "origin_airport_code": "MAA",
      "dest_airport_code": "CJB",
      "origin_airport_name": "Chennai",
      "dest_airport_name": "Coimbatore",
      "adult": "1",
      "child": 0,
      "infant": 0,
      "date_departure": "2019-05-22",
      "return_date_departure": "",
      "time_departure": "13:20",
      "time_arrival": "14:30",
      "return_time_departure": "",
      "return_time_arrival": "",
      "tax": 482,
      "base_fare": 1350,
      "discount": 0,
      "cancellation_fee": {
        "ADT": 2500
      },
      "seats": 9,
      "trip_type": "O",
      "stops": 0,
      "currency_type": "INR",
      "return_stops": 0,
      "via_flights": [
        {
          "origin_airport_code": "MAA",
          "dest_airport_code": "CJB",
          "origin_airport_name": "Chennai",
          "dest_airport_name": "Coimbatore",
          "origin_airport_details": {
            "airport_detail_id": "7277",
            "airport_name": "Chennai International Airport",
            "city_name": "Chennai",
            "airport_code": "MAA",
            "continent_code": "AS",
            "country_code": "IN",
            "coordinates": [
              "12.99000549",
              "80.16929626"
            ],
            "airport_type": "large_airport",
            "time_zone": "Asia/Kolkata",
            "offset": "+05:30",
            "status": "Y"
          },
          "dest_airport_details": {
            "airport_detail_id": "7268",
            "airport_name": "Coimbatore International Airport",
            "city_name": "Coimbatore",
            "airport_code": "CJB",
            "continent_code": "AS",
            "country_code": "IN",
            "coordinates": [
              "11.02999973",
              "77.04340363"
            ],
            "airport_type": "medium_airport",
            "time_zone": "Asia/Kolkata",
            "offset": "+05:30",
            "status": "Y"
          },
          "arrival_terminal": "",
          "departure_terminal": "1",
          "time_departure": "13:20",
          "time_arrival": "14:30",
          "arrival_date": "2019-05-22",
          "departure_date": "2019-05-22",
          "meal_code": "S",
          "cabin_class": "E",
          "faretypename": "Refundable",
          "faretype_code": "R",
          "trip_type": "O",
          "flight_number": 429,
          "airline_code": "AI",
          "airline_name": "Air India",
          "travel_time": "1h 10m",
          "total_time": "1h 10m",
          "layover_time": "",
          "fare_basic_code": {
            "adult": "SAP8",
            "child": "",
            "infant": ""
          },
          "baggage_allowance": {
            "CB": {
              "ADT": {
                "Weight": 25,
                "Unit": "kg"
              }
            }
          },
          "operating_airline_code": "AI",
          "operating_airline_name": "Air India",
          "operating_flight_number": 429,
          "mealAvailable": "YES"
        }
      ],
      "passenger_fare": [
        {
          "passenger_type": "ADT",
          "base_fare": 1350,
          "tax": 482,
          "old_base_fare": 0,
          "old_tax": 0,
          "discount": 0,
          "taxBreakUpDetails": [
            {
              "taxCode": "YR",
              "taxAmount": 170,
              "taxDescription": "Service Charge"
            },
            {
              "taxCode": "IN",
              "taxAmount": 82,
              "taxDescription": "User Development Fee"
            },
            {
              "taxCode": "GST",
              "taxAmount": 76,
              "taxDescription": "Government Service Tax"
            },
            {
              "taxCode": "WO",
              "taxAmount": 154,
              "taxDescription": "Passenger Service Fee"
            }
          ]
        }
      ]
    }
  }
}';
*/
//$_Adata = json_decode($_Adata,1);
?>
<!--Mail Template used to display the Flight Design -->
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
   <head>
      <title> Mail Template </title>
      <meta name="generator" content="editplus" />
      <meta name="author" content="" />
      <meta name="keywords" content="" />
      <meta name="description" content="" />
   </head>
   <body>
      <table cellspacing="1" cellpadding="0" border="0" align="center" width="700" bgcolor="#cccccc">
         <tr>
            <td valign="top">
               <table cellspacing="0" cellpadding="0" border="0" align="center" width="699" bgcolor="#ffffff">
                  <td height="100" bgcolor="#0a4d82">
                     <table cellspacing="0" cellpadding="0" border="0" align="center" width="100%">
                        <tr>
                           <td height="10"><img src="http://testbalmer.agencyauto.net/libimages/spacer.gif" width="1" height="10" border="0" alt=""></td>
                        </tr>
                        <tr>
                           <td valign="top">
                              <table cellspacing="0" cellpadding="0" border="0" align="center" width="100%">
                                 <tr>
                                    <td width="30" align="center">
                                    </td>
                                    <td valign="top">
                                       <table cellspacing="0" cellpadding="0" border="0" width="100%">
                                          <tr>
                                             <td height="10">
                                             </td>
                                          </tr>
                                          <tr>
                                             <td width="40">
                                                <img src="http://192.168.6.90/images/booking-logo.png" width="100">
                                             </td>
                                             <td style="font-size:16px; font-family:arial; color:#fff;">
                                                <font style="padding-top:10px;font-size:16px; font-family:arial; color:#fff; line-height:0px;"><strong>TRACE ROUTE</strong></font>
                                             </td>
                                          </tr>
                                           <tr>
                                             <td height="10">
                                             </td>
                                          </tr>
                                       </table>
                                    </td>
                                 </tr>
                              </table>
                           </td>
                        </tr>
                        <tr>
                           <td height="10"><img src="http://testbalmer.agencyauto.net/libimages/spacer.gif" width="1" height="10" border="0" alt=""></td>
                        </tr>
                     </table>
                  </td>
                  <tr>
                     <td valign="top">
                        <table cellspacing="0" cellpadding="0" border="0" width="100%">                 
                           <tr>
                              <td height="15" colspan="3"><img src="images/spacer.gif" width="1" height="10" border="0" alt=""></td>
                           </tr>
                           <tr>
                              <td width="10"><img src="images/spacer.gif" width="10" height="1" border="0" alt=""></td>
                              <td style="font-size:13px; font-family:arial; color:#000;" align="center">
                                 <font style="font-size:13px; font-family:arial; color:#000; line-height:22px; text-align:left;"> 
                                    <h3>Dear <?php echo $employeeName; ?>,</h3>
                                    <p style="padding-left: 20px">Based on your previous travel dates, we have listed you the flights for the frequently travelled sector.
                                      Hope you are ready to travel!!!</p>
                                 </font>
                              </td>
                              <td width="10"><img src="images/spacer.gif" width="10" height="1" border="0" alt=""></td>
                           </tr>
                           <tr>
                              <td width="10"><img src="images/spacer.gif" width="10" height="1" border="0" alt=""></td>
                              <td valign="top">
                                 <table cellspacing="0" cellpadding="0" border="0" align="center" width="100%">
                                    <!--Flight Details Start-->
                                 <tr>
                                    <td height="15"><img src="images/spacer.gif" width="1" height="20" border="0" alt=""></td>
                                 </tr>              
                                    <!--------- Flight Itinerary Info starts------->
                                 <tr>
                                    <td height="20"><img src="images/spacer.gif" width="1" height="20" border="0" alt=""></td>
                                 </tr>
                                 <tr>
                                    <td valign="top">
                                       <table cellspacing="0" cellpadding="0" border="0" width="100%">
                                          <tr>
                                             <td width="15"><img src="images/spacer.gif" width="15" height="1" border="0" alt=""></td>
                                             <td style="font-size:13px; font-family:arial; color:#333;">
                                                <font style="font-size:13px; font-family:arial; color:#333; line-height:22px;">
                                                   <strong>Flight Details</strong>
                                                </font>
                                             </td>
                                          </tr>
                                       </table>
                                    </td>
                                 </tr>                                    
                                 <tr>
                                    <td height="5"><img src="images/spacer.gif" width="1" height="5" border="0" alt=""></td>
                                 </tr>
                                 <tr>
                                    <td valign="top">
                                       <table cellspacing="0" cellpadding="0" border="0" width="100%">
                                          <tr>
                                             <td width="15"><img src="images/spacer.gif" width="15" height="1" border="0" alt=""></td>
                                             <td style="border-top:1px solid #C1C3C9"></td>
                                             <td width="15"><img src="images/spacer.gif" width="15" height="1" border="0" alt=""></td>
                                          </tr>
                                       </table>
                                    </td>
                                 </tr>
                                 <tr>
                                    <td height="15"><img src="images/spacer.gif" width="1" height="15" border="0" alt=""></td>
                                 </tr>
                                 <?php
                                 /*it used to assign the flight data with respect to the field*/
                                 foreach ($_Adata as $key => $value) {
                                    if ($value['status_code'] =='0' && $value['data'][0]!='EMPTY') {
                                    
                                 echo '<tr>
                                    <td valign="top">
                                       <table cellspacing="0" cellpadding="0" border="0" width="100%">
                                          <tr>
                                             <td width="15"><img src="images/spacer.gif" width="15" height="1" border="0" alt=""></td>
                                             <td width="25">
                                                <img src="http://192.168.6.90/images/flight.png" border="0" alt="">
                                             </td>
                                             <td style="font-size:13px; font-family:arial; color:#444;">
                                                <font style="font-size:13px; font-family:arial; color:#000; line-height:22px;">
                                                   <strong> '.$value['data']['origin_airport_name'].' <font style="vertical-align:1px;">&#x2192;
                                                   </font> '.$value['data']['dest_airport_name'].'</strong>
                                                </font>
                                                <font style="font-size:13px; font-family:arial; color:#444; line-height:22px;">
                                                '.date_format(date_create($value['data']['date_departure']),"D, M d Y").'
                                                </font>
                                             </td>
                                             <td width="15"><img src="../libimages/spacer.gif" width="15" height="1" border="0" alt=""></td>
                                          </tr>
                                       </table>
                                    </td>
                                 </tr>
                                 <tr>
                                    <td height="10"><img src="images/spacer.gif" width="1" height="10" border="0" alt=""></td>
                                 </tr>
                                 <tr>
                                    <td valign="top">
                                       <table cellspacing="0" cellpadding="0" border="0" width="100%">
                                          <tr>
                                             <td width="15"><img src="images/spacer.gif" width="15" height="1" border="0" alt=""></td>
                                             <td width="35"><img src="http://192.168.6.90/images/'.$value['data']['via_flights'][0]['airline_code'].'.png" border="0" alt="" onerror='.'"this.src='."'".'images/DF.png'."'".'"></td>
                                             <td style="font-size:13px; font-family:arial; color:#444;">
                                                <font style="font-size:13px; font-family:arial; color:#444; line-height:22px;">
                                                   '.$value['data']['via_flights'][0]['airline_name'].'
                                                   </font><br/>
                                                   <font style="font-size:12px; font-family:arial; color:#ccc; line-height:22px;">
                                                   
                                                   '.$value['data']['via_flights'][0]['airline_code'] . $value['data']['via_flights'][0]['flight_number'].'
                                                </font>
                                             </td>
                                             <td style="font-size:13px; font-family:arial; color:#ccc; line-height:22px;" align="center">
                                                <font style="font-size:13px; font-family:arial; color:#000; line-height:22px;">
                                                   <strong> '.$value['data']['origin_airport_code'].' </strong>
                                                   </font><br/>
                                                   <font style="font-size:13px; font-family:arial; color:#000; line-height:22px;">
                                                   '.$value['data']['time_departure'].'
                                                </font>
                                             </td>
                                             <td align="center">
                                                <img src="http://192.168.6.90/images/time.png" border="0" alt=""><br/>
                                                   <font style="font-size:13px; font-family:arial; color:#000; line-height:22px;">
                                                  '.$value['data']['via_flights'][0]['total_time'].'
                                                  </font>
                                             </td>
                                             <td style="font-size:13px; font-family:arial; color:#ccc; line-height:22px;" align="center">
                                                <font style="font-size:13px; font-family:arial; color:#000; line-height:22px;">
                                                      <strong>'.$value['data'][
                                                         'dest_airport_code'].' </strong>
                                                      </font><br/>
                                                      <font style="font-size:13px; font-family:arial; color:#000; line-height:22px;">
                                                      '.$value['data']['time_arrival'].'
                                                </font>
                                             </td>
                                             <td style="font-size:13px; font-family:arial; color:#ccc; line-height:22px;" align="center">
                                                   <font style="font-size:13px; font-family:arial; color:#000; line-height:22px;">
                                                      <strong> Low Fare </strong>
                                                   </font><br/>
                                                   <font style="font-size:13px; font-family:arial; color:#000; line-height:22px;">
                                                      &#x20b9;  '.$value['data']['base_fare'].'
                                                   </font>
                                             </td>
                                             <td style="font-size:13px; font-family:arial; color:#619D24; line-height:22px;" align="center">
                                                <a href="http://corporate.atyourprice.net/">Book Now</a>
                                             </td>
                                             <td width="15"><img src="../libimages/spacer.gif" width="15" height="1" border="0" alt=""></td>
                                          </tr>
                                          
                                       </table>
                                       <tr>
                                              <td style="border-top:1px solid #C1C3C9"></td>
                                          </tr>
                                    </td>
                                 </tr>';
                                 }
                                 }
                                 ?>
                                 <tr>
                                    <td height="10"><img src="../libimages/spacer.gif" width="1" height="10" border="0" alt=""></td>
                                 </tr>
                                 <tr>
                                    <td valign="top">
                                       <table cellspacing="0" cellpadding="0" border="0" width="100%">
                                          <tr>
                                             <td width="15"><img src="../libimages/spacer.gif" width="15" height="1" border="0" alt=""></td>
                                            
                                             <td width="15"><img src="../libimages/spacer.gif" width="15" height="1" border="0" alt=""></td>
                                          </tr>
                                       </table>
                                    </td>
                                 </tr>
                                 <tr>
                                    <td height="10"><img src="../libimages/spacer.gif" width="1" height="10" border="0" alt=""></td>
                                 </tr>
                                 <tr>
                                    <td height="40" bgcolor="#ccc" align="center">
                                       <font style="font-size:12px; font-family:arial; color:#000; line-height:22px;">
                                          Powered by <a href="http://infinitisoftware.net/" style="font-size:12px; font-family:arial; color:#000; line-height:22px; text-decoration:none;" target="_blank" title="Infiniti Software Solutions" alt="Infiniti Software Solutions">Infiniti Software Solutions</a>
                                       </font>
                                    </td>                  
                                 </tr>  
                              </tr>
                           </table>
                        </td>
                     </tr> 
                  </tr>
               </table>
   </body>
</html> 

 